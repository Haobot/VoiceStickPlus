// assets/charts.js — Mermaid 初始化 + 目录滚动高亮
(function () {
  'use strict';

  // ---------- Mermaid ----------
  if (window.mermaid) {
    var style = getComputedStyle(document.documentElement);
    var ink = style.getPropertyValue('--ink').trim() || '#1a2332';
    var muted = style.getPropertyValue('--muted').trim() || '#5b6675';
    var rule = style.getPropertyValue('--rule').trim() || '#dbe1e9';
    var accent = style.getPropertyValue('--accent').trim() || '#2563eb';
    var bg2 = style.getPropertyValue('--bg2').trim() || '#f4f6f9';
    var sans = style.getPropertyValue('--sans').trim() || 'sans-serif';

    mermaid.initialize({
      startOnLoad: true,
      theme: 'neutral',
      securityLevel: 'loose',
      fontFamily: sans,
      themeVariables: {
        primaryColor: '#e8eefb',
        primaryTextColor: ink,
        primaryBorderColor: accent,
        lineColor: muted,
        secondaryColor: '#e9f6f3',
        tertiaryColor: bg2,
        noteBkgColor: bg2,
        noteTextColor: ink,
        noteBorderColor: rule,
        actorBkg: '#e8eefb',
        actorBorder: accent,
        actorTextColor: ink,
        signalColor: muted,
        signalTextColor: ink,
        labelBoxBkgColor: '#e8eefb',
        labelBoxBorderColor: accent,
        loopTextColor: ink,
        activationBkgColor: '#e9f6f3',
        sequenceNumberColor: '#ffffff'
      },
      flowchart: { curve: 'basis', htmlLabels: true, useMaxWidth: true },
      sequence: { useMaxWidth: true, wrap: false },
      state: { useMaxWidth: true }
    });
  }

  // ---------- TOC scrollspy ----------
  var tocLinks = Array.prototype.slice.call(document.querySelectorAll('.toc a[href^="#"]'));
  var linkMap = {};
  tocLinks.forEach(function (a) {
    var id = a.getAttribute('href').slice(1);
    if (id) { linkMap[id] = a; }
  });

  var headings = Array.prototype.slice.call(document.querySelectorAll('main h2[id], main h3[id]'));
  if ('IntersectionObserver' in window && headings.length) {
    var visible = {};
    var pick = function () {
      // 选择视口中当前可见的最后一个标题
      var best = null;
      headings.forEach(function (h) {
        if (!visible[h.id]) { return; }
        if (!best || h.offsetTop >= best.offsetTop) { best = h; }
      });
      if (!best) { return; }
      var target = best;
      // 高亮所属章节：h3 命中时同时点亮父级 h2
      tocLinks.forEach(function (a) { a.classList.remove('active'); });
      var h = linkMap[target.id];
      if (h) { h.classList.add('active'); }
      if (target.tagName === 'H3') {
        var sec = target.closest('section');
        if (sec && sec.id && linkMap[sec.id]) { linkMap[sec.id].classList.add('active'); }
      }
    };
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { visible[e.target.id] = e.isIntersecting; });
      pick();
    }, { rootMargin: '0px 0px -70% 0px', threshold: 0 });
    headings.forEach(function (h) { observer.observe(h); });
  }

  // ---------- Mobile TOC: collapse after navigation ----------
  document.querySelectorAll('.toc-mobile a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function () {
      var d = a.closest('details');
      if (d) { d.removeAttribute('open'); }
    });
  });

  // ---------- Back to top ----------
  var totop = document.getElementById('totop');
  if (totop) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 600) { totop.classList.add('show'); }
      else { totop.classList.remove('show'); }
    }, { passive: true });
  }
})();
